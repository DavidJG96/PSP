package org.example;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;


public class Cliente {
    private final Socket cliente;
    private final DataOutputStream outs;
    private final BufferedReader inps;

    public Cliente(String host, int port) throws UnknownHostException, IOException {
        cliente = new Socket(host, port);
        outs = new DataOutputStream(cliente.getOutputStream());
        inps = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
    }

    public void sendReceive(String message) {
        try {
            System.out.println("Enviando al servidor: " + message);
            outs.writeBytes(message + "\n");
            outs.flush();
            // leyendo del socket
            // una vez que recibamos respuesta usaremos break para salir
            String responseLine = inps.readLine();
            if (responseLine != null) {
                System.out.println("Respuesta del servidor: " + responseLine);
                close();
            } else {
                System.out.println("El servidor no ha enviado respuesta");
            }
        } catch (UnknownHostException e) {
            System.err.println("Fallo en el host especificado");
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public void close() throws IOException {
        sendReceive("cerrar");
        inps.close();
        outs.close();
    }

    public static void main(String[] args) throws UnknownHostException, IOException, InterruptedException {

                 Cliente cliente = new Cliente("localhost", 5566);
                    cliente.sendReceive("Hola");



    }
}
