package org.example;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


        public class Servidor {
            public static void main (String[] args) {
                try {
                    ServerSocket server = new ServerSocket(5566);
                    while (true) {
                        System.out.print("Esperando conexiones.");
                        Socket client = server.accept();
                        RespuestaEco handler = new RespuestaEco(client);
                        handler.start();
                    }
                }
                catch (Exception e) {
                    System.err.println("Exception caught:" + e);
                }
            }
        }

        class RespuestaEco extends Thread {
            Socket cliente;
            RespuestaEco (Socket client) {
                this.cliente = client;
            }

            public void run () {
                try {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
                    PrintWriter writer = new PrintWriter(cliente.getOutputStream(), true);

                    while (true) {
                        String line = reader.readLine();
                        if (line.trim().equals("cerrar")) {
                            writer.println("Cerrando conexion");
                            break;
                        }
                        writer.println("Eco servidor " + line);
                    }
                }
                catch (Exception e) {
                    System.err.println("Exception caught: client disconnected.");
                }
                finally {
                    try { cliente.close(); }
                    catch (Exception e ){ ; }
                }
            }
        }
