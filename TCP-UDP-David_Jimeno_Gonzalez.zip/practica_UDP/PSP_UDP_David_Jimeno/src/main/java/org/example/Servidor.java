package org.example;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;


public class Servidor extends Thread {

    private DatagramSocket socket;
    private boolean run;
    private byte[] buffer = new byte[1024];

    public Servidor() {
        try {
            socket = new DatagramSocket(1919);
        } catch (SocketException e) {
            throw new RuntimeException(e);
        }
    }

    public void run() {
        run = true;
        System.out.print("Servidor en marcha!");

        while (run) {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            try {
                socket.receive(packet);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            InetAddress direccion = packet.getAddress();
            int puerto = packet.getPort();
            packet = new DatagramPacket(buffer, buffer.length, direccion, puerto);
            String recibido = new String(packet.getData(), 0, packet.getLength());

            if (recibido.equals("parada")) {
                run = false;
                continue;
            }
            try {
                socket.send(packet);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        socket.close();
    }

    public static void main(String[] args) throws Exception {
        new Servidor().start();
    }
}
