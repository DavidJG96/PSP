package org.example;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

 public class Cliente {

    public static void main(String[] args) throws Exception {
        String hostname = "localhost";
        InetAddress ia = InetAddress.getByName(hostname);
        ThreadEmisor emisor = new ThreadEmisor(ia, 1919);
        emisor.start();
        Thread receptor = new ThreadReceptor(emisor.getSocket());
        receptor.start();
    }

}

 class ThreadEmisor extends Thread {

    private InetAddress servidor;

    private DatagramSocket socket;

    private boolean parada = false;

    private int puerto;

    public ThreadEmisor(InetAddress address, int puerto) throws SocketException {
        this.servidor = address;
        this.puerto = puerto;
        this.socket = new DatagramSocket();
        this.socket.connect(servidor, puerto);
    }

    public void parada() {
        this.parada = true;
    }

    public DatagramSocket getSocket() {
        return this.socket;
    }

    public void run() {

        try {
            BufferedReader texto = new BufferedReader(new InputStreamReader(System.in));
            while (true) {
                if (parada)
                    return;
                String theLine = texto.readLine();
                if (theLine.equals("parar"))
                    break;
                byte[] data = theLine.getBytes();
                DatagramPacket paqSalida = new DatagramPacket(data, data.length, servidor, puerto);
                socket.send(paqSalida);
                Thread.yield();
            }
        }
        catch (IOException ex) {
            System.err.println(ex);
        }
    }
}

class ThreadReceptor extends Thread {
    DatagramSocket socket;

    private boolean parada = false;

    public ThreadReceptor(DatagramSocket ds) throws SocketException {
        this.socket = ds;
    }

    public void parada() {
        this.parada = true;
    }

    public void run() {
        byte[] buffer = new byte[1024];
        while (true) {
            if (parada)
                return;
            DatagramPacket datp = new DatagramPacket(buffer, buffer.length);
            try {
                socket.receive(datp);
                String s = new String(datp.getData(), 0, datp.getLength());
                System.out.println("Servidor: " + s);
                Thread.yield();
            } catch (IOException ex) {
                System.err.println(ex);
            }
        }
    }
}